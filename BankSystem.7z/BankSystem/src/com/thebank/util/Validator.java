package com.thebank.util;

public class Validator {
	public static boolean validateUserName(String name) {
		return name.matches("[a-zA-Z0-9]{3,}");
	}
	
	public static boolean validateCustomerName(String name) {
		return name.matches("[A-Za-z ]{3,}");
	}
	
	public static boolean validateAccountNumber(String accountNumberString) {
		return accountNumberString.matches("\\d{6,10}");
	}
	
	public static boolean validatePassword(String password) {
		return password.matches("[0-9a-zA-Z!@#$%\\^\\&\\*\\(\\)]{5,15}");
	}
	
	public static boolean validateEmail(String email) {
		return email.matches("\\w+(\\.?\\w+|\\w*)@\\w+\\.\\w+");
	}
	
	public static boolean validateMobileNumber(String mobileno) {
		return mobileno.matches("[6-9]{1}[0-9]{9}");
	}
	
	public static boolean validatePinCode(String pincode) {
		return pincode.matches("\\d{6}");
	}
	
	public static boolean validatePanCard(String pancard) {
		return pancard.matches("[A-Z]{5}[0-9]{4}[A-Z]{1}");
	}
	
	public static boolean validateDate(String dateString) {
		return dateString.matches("([1-9]|0[1-9]|1[0-9]|2[0-9]|3[0-1])[-]([1-9]|0[1-9]|1[0-2])[-][1-2][0-9]{3}");
	}
	

}