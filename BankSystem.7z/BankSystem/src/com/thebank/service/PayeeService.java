package com.thebank.service;

import java.util.Set;

import com.thebank.dao.IPayeeDao;
import com.thebank.dao.PayeeDao;
import com.thebank.model.Payee;

public class PayeeService implements IPayeeService{
	
	public PayeeService() {
		
	}

	public PayeeService(IPayeeDao payeeDao) {
		this.payeeDao=payeeDao;
	}
	
	IPayeeDao payeeDao = new PayeeDao();
	
	@Override
	public boolean addPayee(Payee payee) {
		if(payee==null)
		{
			throw new IllegalArgumentException();
		}
		return payeeDao.addPayee(payee);
	}

	@Override
	public Payee getPayeeFromPayeeAccountId(long payeeAccountId) {
		return payeeDao.getPayeeFromPayeeAccountId(payeeAccountId);
	}

	@Override
	public Set<Payee> getAllPayees() {
		return payeeDao.getAllPayees();
	}

	@Override
	public Set<Payee> getAllPayeeOfAccountId(long accountId) {
		return payeeDao.getAllPayeeOfAccountId(accountId);
	}

}
