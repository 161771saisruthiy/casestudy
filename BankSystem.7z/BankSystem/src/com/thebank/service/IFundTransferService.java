package com.thebank.service;

import java.util.Set;

import com.thebank.exception.InsufficientAccountBalanceException;
import com.thebank.model.FundTransfer;

public interface IFundTransferService {

	public boolean addFundTransfer(FundTransfer fundTransfer) throws InsufficientAccountBalanceException;
	public FundTransfer getFundTransferFromFundTranferId(long fundTranferId);
	public Set<FundTransfer> getAllFundTransfers();
	public Set<FundTransfer> getAllFundTransfersFromAccountId(long accountId);
}
