package com.thebank.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.Set;

import org.apache.log4j.Logger;

import com.thebank.model.Payee;

public class PayeeDao implements IPayeeDao{
	
	final static Logger logger=Logger.getLogger(PayeeDao.class);
	
	private static final String PAYEE_TABLE = "payee";
	private static final String COLUMN_ACCOUNT_ID = "accountId";
	private static final String COLUMN_PAYEE_ACCOUNT_ID = "payeeAccountId";
	private static final String COLUMN_NICK_NAME = "nickName";
	
	@Override
	public boolean addPayee(Payee payee) {
		try(Connection connection = DatabaseConnection.getConnection()) {

			String sql="insert into "+PAYEE_TABLE+"("
					+COLUMN_ACCOUNT_ID+","
					+COLUMN_PAYEE_ACCOUNT_ID+","
					+COLUMN_NICK_NAME+")"
					+" values(?,?,?)";
			PreparedStatement preparedStatement=connection.prepareStatement(sql);
			preparedStatement.setLong(1, payee.getAccountId());
			preparedStatement.setLong(2, payee.getPayeeAccountId());
			preparedStatement.setString(3,payee.getNickname());
			
			int count = preparedStatement.executeUpdate();
			
			if(count>0) {
				logger.info("Payee added Successfully");
				return true;
			}
		} catch (SQLException e) {
			logger.error("Payee addition failed");
			//e.printStackTrace();
		}
		
		return false;
	}

	@Override
	public Payee getPayeeFromPayeeAccountId(long payeeAccountId) {
		try(Connection connection = DatabaseConnection.getConnection()) {
			String sql = "select * from "+PAYEE_TABLE+" where "
					+ COLUMN_PAYEE_ACCOUNT_ID +"=?";
			PreparedStatement statement = connection.prepareStatement(sql);
			statement.setLong(1, payeeAccountId);
			
			ResultSet resultSet = statement.executeQuery();
			if(resultSet.next()) {
				Payee payee = new Payee();
				payee.setAccountId(resultSet.getLong(COLUMN_ACCOUNT_ID));
				payee.setPayeeAccountId(payeeAccountId);
				payee.setNickname(resultSet.getString(COLUMN_NICK_NAME));
				
				logger.info("Payee details retrieved successfully");
				return payee;
			}
			else {
				logger.info("Payee details retrieval failed ");
			}
			
		} catch (SQLException e) {
			logger.error("Failed to retrieve Payee details");
			//e.printStackTrace();
		}
		return null;
	}

	@Override
	public Set<Payee> getAllPayees() {
		Set<Payee> payees = new HashSet<>();
		try(Connection connection = DatabaseConnection.getConnection()) {
			String sql = "select * from "+PAYEE_TABLE;
			PreparedStatement statement = connection.prepareStatement(sql);
			
			ResultSet resultSet = statement.executeQuery();
			while(resultSet.next()) {
				Payee payee = new Payee();
				payee.setAccountId(resultSet.getLong(COLUMN_ACCOUNT_ID));
				payee.setPayeeAccountId(resultSet.getLong(COLUMN_PAYEE_ACCOUNT_ID));
				payee.setNickname(resultSet.getString(COLUMN_NICK_NAME));

				
				payees.add(payee);
			}
			if(payees.size()==0) {
				logger.info("No Payee exists");
			}
			else {
				logger.info("Payees exist");
			}
			return payees;
			
		} catch (SQLException e) {
			logger.error("Exception during Payee retrieval");
			//e.printStackTrace();
		}
		return null;
	}
	
	//get all the payees of accountID
	@Override
	public Set<Payee> getAllPayeeOfAccountId(long accountId) {
		Set<Payee> payees = new HashSet<>();
		try(Connection connection = DatabaseConnection.getConnection()) {
			String sql = "select * from "+PAYEE_TABLE+" where "
					+COLUMN_ACCOUNT_ID + "=?";
			PreparedStatement statement = connection.prepareStatement(sql);
			statement.setLong(1, accountId);
			
			ResultSet resultSet = statement.executeQuery();
			while(resultSet.next()) {
				Payee payee = new Payee();
				payee.setAccountId(resultSet.getLong(COLUMN_ACCOUNT_ID));
				payee.setPayeeAccountId(resultSet.getLong(COLUMN_PAYEE_ACCOUNT_ID));
				payee.setNickname(resultSet.getString(COLUMN_NICK_NAME));

				payees.add(payee);
			}
			if(payees.size()==0) {
				logger.info("No Payee exists");
			}
			else {
				logger.info("Payees exist");
			}
			return payees;
			
		} catch (SQLException e) {
			logger.error("Exception during Payee retrieval");
			//e.printStackTrace();
		}
		return null;
	}
}
