package com.thebank.model;

import java.util.Set;

public class Customer {

	private long customerId;
	private String customerName;
	private String email;
	private String mobileNo;
	private String address;
	private String pancard;
	private Set<Account> accounts;
	
	public Customer() {
		
	}
	
	
	public Customer(long customerId, String customerName, String email, String mobileNo, String address, String pancard,
			Set<Account> accounts) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.email = email;
		this.mobileNo = mobileNo;
		this.address = address;
		this.pancard = pancard;
		this.accounts = accounts;
	}


	public String getMobileNo() {
		return mobileNo;
	}


	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}


	public long getCustomerId() {
		return customerId;
	}
	public void setCustomerId(long customerId) {
		this.customerId = customerId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getPancard() {
		return pancard;
	}
	public void setPancard(String pancard) {
		this.pancard = pancard;
	}
	public Set<Account> getAccounts() {
		return accounts;
	}
	public void setAccounts(Set<Account> accounts) {
		this.accounts = accounts;
	}


	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", customerName=" + customerName + ", email=" + email
				+ ", mobileNo=" + mobileNo + ", address=" + address + ", pancard=" + pancard + ", accounts=" + accounts
				+ "]";
	}

	
	

}
