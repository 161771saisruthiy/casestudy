package com.thebank.model;

import java.time.LocalDate;

public class ServiceTracker {
	
	private long serviceId;
	private String serviceDescription;
	private long accountId;
	private LocalDate serviceRaisedDate;
	private String serviceStatus;
	
	public long getServiceId() {
		return serviceId;
	}
	public void setServiceId(long serviceId) {
		this.serviceId = serviceId;
	}
	public String getServiceDescription() {
		return serviceDescription;
	}
	public void setServiceDescription(String serviceDescription) {
		this.serviceDescription = serviceDescription;
	}
	public long getAccountId() {
		return accountId;
	}
	public void setAccountId(long accountId) {
		this.accountId = accountId;
	}
	public LocalDate getServiceRaisedDate() {
		return serviceRaisedDate;
	}
	public void setServiceRaisedDate(LocalDate serviceRaisedDate) {
		this.serviceRaisedDate = serviceRaisedDate;
	}
	public String getServiceStatus() {
		return serviceStatus;
	}
	public void setServiceStatus(String serviceStatus) {
		this.serviceStatus = serviceStatus;
	}
	@Override
	public String toString() {
		return "ServiceTracker [serviceId=" + serviceId + ", serviceDescription="
				+ serviceDescription + ", accountId=" + accountId + ", serviceRaisedDate=" + serviceRaisedDate
				+ ", serviceStatus=" + serviceStatus + "]";
	}
	public ServiceTracker() {
		super();
	}
	public ServiceTracker(long serviceId, String serviceDescription, long accountId,
			LocalDate serviceRaisedDate, String serviceStatus) {
		super();
		this.serviceId = serviceId;
		this.serviceDescription = serviceDescription;
		this.accountId = accountId;
		this.serviceRaisedDate = serviceRaisedDate;
		this.serviceStatus = serviceStatus;
	}
	
	
}
