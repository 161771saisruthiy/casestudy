package com.thebank.boot;

import com.thebank.view.MenuUI;
import com.thebank.view.PromptUI;
import com.thebank.view.ServiceUI;
import com.thebank.view.UserInteraction;

//Application starts
public class BootClass {

	public static void main(String[] args) {
				
		do {
			int choice = MenuUI.getTaskType();  //Identify user as Admin or customer
			switch(choice) {
				case 1:									
					UserInteraction.doCustomerTasks(); //Account Holder Login
					break; 		
				case 2:			
					if(PromptUI.checkAdminPassword()) {//Admin login
						UserInteraction.doAdminTasks(); //Tasks performed by Admin
					}
					break;
				case 3:
					ServiceUI.signUp(); //New user?sign up
					break;
				case 4:
					System.out.println("\t****************************\n");
					System.out.println("\tThank you! Have a nice Day :)");
					System.out.println("_____________________________");
					System.exit(0); //Exit Application
					break;
			}
		}while(MenuUI.getRepeatConfirmation()); //if wrong choice entered Prompt user identification again 
		System.out.println("\t********************");
		System.out.println("\tThank you! Have a nice Day :)");
		System.out.println("______________________________");
	}
}