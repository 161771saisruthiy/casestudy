package com.thebank.service;

import java.util.Set;

import com.thebank.model.Account;
import com.thebank.model.ServiceTracker;

public interface IServiceTrackerService {

	public boolean addServiceTracker(ServiceTracker serviceTracker);
	public ServiceTracker getServiceFromServiceId(long serviceId);
	public Set<ServiceTracker> getAllServicesOfCustomer(long customerId);
	public Set<ServiceTracker> getAllServicesOfAccount(long accountId);
	public boolean addChequebookRequest(Account account);
}
